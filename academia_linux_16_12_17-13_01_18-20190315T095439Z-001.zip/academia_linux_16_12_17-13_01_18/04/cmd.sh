# cmd.sh
# This script is used for basic shell constructs and syntax
# Usage examples
# cmd.sh d 
# 	run data command 
# cmd.sh c 
# 	run cal command 
# cmd.sh g filename [number]
# 	generates [number] files
# OPT=debug cmd.sh
# 	show debugging information set -x
